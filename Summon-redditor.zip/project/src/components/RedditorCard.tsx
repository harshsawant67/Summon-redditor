import React from 'react';
import { RedditUser } from '../types';
import { Trophy, Zap, Flame, Calendar, Star } from 'lucide-react';

interface RedditorCardProps {
  user: RedditUser;
  className?: string;
  showBattleStats?: boolean;
}

export const RedditorCard: React.FC<RedditorCardProps> = ({ 
  user, 
  className = '', 
  showBattleStats = false 
}) => {
  return (
    <div className={`bg-white rounded-2xl shadow-xl p-6 transform hover:scale-105 transition-all duration-300 border-2 border-orange-100 hover:border-orange-300 ${className}`}>
      {/* Avatar and Basic Info */}
      <div className="text-center mb-6">
        <img 
          src={user.avatar} 
          alt={user.username}
          className="w-24 h-24 mx-auto rounded-full border-4 border-orange-200 shadow-lg mb-4"
        />
        <h3 className="text-2xl font-bold text-gray-800 mb-1">
          u/{user.username}
        </h3>
        <div className="flex items-center justify-center gap-2 text-sm text-gray-600">
          <Calendar className="w-4 h-4" />
          <span>Redditor for {user.accountAge}</span>
          <span className="text-2xl">{user.favoriteEmoji}</span>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-gradient-to-br from-orange-50 to-orange-100 rounded-lg p-3 text-center">
          <div className="flex items-center justify-center gap-1 mb-1">
            <Zap className="w-4 h-4 text-orange-600" />
            <span className="text-xs font-semibold text-orange-700 uppercase">Upvote Power</span>
          </div>
          <div className="text-xl font-bold text-orange-800">
            {user.upvotePower.toLocaleString()}
          </div>
        </div>

        <div className="bg-gradient-to-br from-red-50 to-red-100 rounded-lg p-3 text-center">
          <div className="flex items-center justify-center gap-1 mb-1">
            <Flame className="w-4 h-4 text-red-600" />
            <span className="text-xs font-semibold text-red-700 uppercase">Cringe Level</span>
          </div>
          <div className="text-xl font-bold text-red-800">
            {user.cringeLevel}%
          </div>
        </div>

        <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-3 text-center">
          <div className="flex items-center justify-center gap-1 mb-1">
            <Star className="w-4 h-4 text-blue-600" />
            <span className="text-xs font-semibold text-blue-700 uppercase">Karma</span>
          </div>
          <div className="text-xl font-bold text-blue-800">
            {user.karma.toLocaleString()}
          </div>
        </div>

        {showBattleStats && (
          <div className="bg-gradient-to-br from-yellow-50 to-yellow-100 rounded-lg p-3 text-center">
            <div className="flex items-center justify-center gap-1 mb-1">
              <Trophy className="w-4 h-4 text-yellow-600" />
              <span className="text-xs font-semibold text-yellow-700 uppercase">Wins</span>
            </div>
            <div className="text-xl font-bold text-yellow-800">
              {user.battleWins || 0}
            </div>
          </div>
        )}
      </div>

      {/* Favorite Subreddits */}
      <div className="mb-4">
        <h4 className="text-sm font-semibold text-gray-700 mb-2">Frequent Hangouts:</h4>
        <div className="flex flex-wrap gap-2">
          {user.subreddits.map((subreddit, index) => (
            <span 
              key={index}
              className="bg-orange-100 text-orange-800 text-xs px-2 py-1 rounded-full font-medium"
            >
              r/{subreddit}
            </span>
          ))}
        </div>
      </div>

      {/* Catchphrases */}
      <div>
        <h4 className="text-sm font-semibold text-gray-700 mb-2">Signature Phrases:</h4>
        <div className="space-y-2">
          {user.phrases.map((phrase, index) => (
            <div 
              key={index} 
              className="bg-gray-50 rounded-lg p-2 text-sm text-gray-600 italic border-l-4 border-orange-300"
            >
              "{phrase}"
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};