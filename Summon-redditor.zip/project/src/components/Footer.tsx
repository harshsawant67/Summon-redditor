import React from 'react';
import { Heart } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-gradient-to-r from-gray-900 to-black text-white py-8 mt-16">
      <div className="max-w-4xl mx-auto px-4 text-center">
        <div className="flex items-center justify-center gap-2 mb-4">
          <span className="text-lg font-semibold">Built with</span>
          <Heart className="w-5 h-5 text-red-500 animate-pulse" />
          <span className="text-lg font-semibold">using</span>
          <a 
            href="https://bolt.new" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-orange-400 hover:text-orange-300 font-bold text-lg transition-colors"
          >
            Bolt.new
          </a>
        </div>
        
        <div className="text-sm text-gray-400 space-y-2">
          <p className="italic">
            "No Redditors were harmed in the making of this game."
          </p>
          <p>
            Disclaimer: This is a parody game for entertainment purposes only. 
            All generated personas are fictional and for laughs.
          </p>
          <p>
            Reddit is a trademark of Reddit Inc. This game is not affiliated with Reddit.
          </p>
        </div>
        
        <div className="mt-6 pt-4 border-t border-gray-700">
          <p className="text-xs text-gray-500">
            Made with React, TypeScript, and way too much Reddit browsing.
          </p>
        </div>
      </div>
    </footer>
  );
};