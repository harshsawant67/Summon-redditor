import React, { useState, useEffect } from 'react';
import { RedditUser } from '../types';
import { RedditorCard } from './RedditorCard';
import { getLeaderboard, getCollection } from '../utils/storage';
import { ArrowLeft, Trophy, Users, Crown, Medal, Award } from 'lucide-react';

interface LeaderboardProps {
  onNavigate: (screen: string) => void;
}

export const Leaderboard: React.FC<LeaderboardProps> = ({ onNavigate }) => {
  const [activeTab, setActiveTab] = useState<'leaderboard' | 'collection'>('leaderboard');
  const [leaderboard, setLeaderboard] = useState<RedditUser[]>([]);
  const [collection, setCollection] = useState<RedditUser[]>([]);

  useEffect(() => {
    setLeaderboard(getLeaderboard());
    setCollection(getCollection());
  }, []);

  const getRankIcon = (position: number) => {
    switch (position) {
      case 0: return <Crown className="w-6 h-6 text-yellow-500" />;
      case 1: return <Medal className="w-6 h-6 text-gray-400" />;
      case 2: return <Award className="w-6 h-6 text-orange-600" />;
      default: return <span className="text-lg font-bold text-gray-600">#{position + 1}</span>;
    }
  };

  const getRankColor = (position: number) => {
    switch (position) {
      case 0: return 'from-yellow-400 to-yellow-600';
      case 1: return 'from-gray-300 to-gray-500';
      case 2: return 'from-orange-400 to-orange-600';
      default: return 'from-blue-400 to-blue-600';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-50 via-orange-50 to-red-50">
      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-800 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Home
          </button>
          
          <h1 className="text-3xl font-bold text-center text-gray-800 flex items-center gap-3">
            <Trophy className="w-8 h-8 text-yellow-500" />
            Hall of Fame
          </h1>
          
          <div className="w-24"></div>
        </div>

        {/* Tab Navigation */}
        <div className="flex justify-center mb-8">
          <div className="bg-white rounded-xl p-1 shadow-lg">
            <button
              onClick={() => setActiveTab('leaderboard')}
              className={`flex items-center gap-2 px-6 py-3 rounded-lg font-semibold transition-all duration-200 ${
                activeTab === 'leaderboard'
                  ? 'bg-gradient-to-r from-yellow-400 to-orange-400 text-white shadow-md'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              <Trophy className="w-5 h-5" />
              Leaderboard
            </button>
            <button
              onClick={() => setActiveTab('collection')}
              className={`flex items-center gap-2 px-6 py-3 rounded-lg font-semibold transition-all duration-200 ${
                activeTab === 'collection'
                  ? 'bg-gradient-to-r from-yellow-400 to-orange-400 text-white shadow-md'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              <Users className="w-5 h-5" />
              Collection ({collection.length})
            </button>
          </div>
        </div>

        {/* Leaderboard Tab */}
        {activeTab === 'leaderboard' && (
          <div>
            {leaderboard.length > 0 ? (
              <div className="space-y-6">
                {leaderboard.map((user, index) => (
                  <div
                    key={user.id}
                    className={`relative bg-gradient-to-r ${getRankColor(index)} p-1 rounded-2xl shadow-xl`}
                  >
                    <div className="bg-white rounded-2xl p-6">
                      <div className="flex items-center gap-4 mb-4">
                        <div className="flex items-center justify-center w-12 h-12 bg-white rounded-full shadow-md">
                          {getRankIcon(index)}
                        </div>
                        <div>
                          <h3 className="text-xl font-bold text-gray-800">
                            Rank #{index + 1}
                          </h3>
                          <p className="text-gray-600">
                            {user.battleWins || 0} battle victories
                          </p>
                        </div>
                      </div>
                      
                      <RedditorCard 
                        user={user} 
                        showBattleStats={true}
                        className="shadow-none border-none"
                      />
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center">
                <div className="bg-white rounded-2xl p-12 shadow-lg max-w-md mx-auto">
                  <Trophy className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h2 className="text-2xl font-bold text-gray-800 mb-4">No Champions Yet</h2>
                  <p className="text-gray-600 mb-6">
                    Battle some Redditors to start populating the leaderboard! 
                    Winners automatically get added to the hall of fame.
                  </p>
                  <button
                    onClick={() => onNavigate('battle')}
                    className="bg-gradient-to-r from-red-500 to-orange-500 hover:from-red-600 hover:to-orange-600 text-white px-6 py-3 rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all duration-200"
                  >
                    Start Battling
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Collection Tab */}
        {activeTab === 'collection' && (
          <div>
            {collection.length > 0 ? (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {collection.map((user, index) => (
                  <div key={user.id} className="relative">
                    <div className="absolute -top-2 -right-2 bg-gradient-to-r from-purple-400 to-pink-400 text-white rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold shadow-lg z-10">
                      {index + 1}
                    </div>
                    <RedditorCard user={user} />
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center">
                <div className="bg-white rounded-2xl p-12 shadow-lg max-w-md mx-auto">
                  <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h2 className="text-2xl font-bold text-gray-800 mb-4">Empty Collection</h2>
                  <p className="text-gray-600 mb-6">
                    Start summoning Redditors and save your favorites to build your collection! 
                    Each saved Redditor becomes part of your personal hall of fame.
                  </p>
                  <button
                    onClick={() => onNavigate('summon')}
                    className="bg-gradient-to-r from-purple-500 to-indigo-500 hover:from-purple-600 hover:to-indigo-600 text-white px-6 py-3 rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all duration-200"
                  >
                    Start Summoning
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Stats Footer */}
        <div className="mt-16 text-center">
          <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 shadow-lg max-w-2xl mx-auto">
            <div className="grid grid-cols-2 gap-6">
              <div>
                <div className="text-3xl font-bold text-yellow-600">{leaderboard.length}</div>
                <div className="text-sm text-gray-600">Champions</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-purple-600">{collection.length}</div>
                <div className="text-sm text-gray-600">Collected</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};