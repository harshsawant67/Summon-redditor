import React from 'react';
import { Sparkles, Users, Zap, Trophy } from 'lucide-react';

interface HomePageProps {
  onNavigate: (screen: string) => void;
}

export const HomePage: React.FC<HomePageProps> = ({ onNavigate }) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-red-50 to-purple-50">
      <div className="max-w-4xl mx-auto px-4 py-12">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <div className="mb-8">
            <div className="inline-flex items-center justify-center w-24 h-24 bg-gradient-to-br from-orange-400 to-red-500 rounded-full shadow-xl mb-6">
              <Users className="w-12 h-12 text-white" />
            </div>
            <h1 className="text-6xl font-bold bg-gradient-to-r from-orange-600 to-red-600 bg-clip-text text-transparent mb-4">
              Summon the Redditor
            </h1>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto leading-relaxed">
              Generate hilariously absurd Reddit personas and watch them battle for internet supremacy! 
              Witness the most epic keyboard warriors emerge from the depths of the hivemind.
            </p>
          </div>

          {/* CTA Button */}
          <button
            onClick={() => onNavigate('summon')}
            className="group relative inline-flex items-center gap-3 bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white px-8 py-4 rounded-2xl font-bold text-xl shadow-xl hover:shadow-2xl transform hover:-translate-y-1 transition-all duration-300"
          >
            <Sparkles className="w-6 h-6 group-hover:animate-spin" />
            Summon Your First Redditor
            <div className="absolute inset-0 bg-gradient-to-r from-orange-400 to-red-400 rounded-2xl blur opacity-30 group-hover:opacity-50 transition-opacity duration-300 -z-10"></div>
          </button>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          <div className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-shadow duration-300 text-center">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <Sparkles className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-xl font-bold text-gray-800 mb-2">Random Generation</h3>
            <p className="text-gray-600">
              Each Redditor is uniquely crafted with real Reddit data, complete with cringe levels and upvote power!
            </p>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-shadow duration-300 text-center">
            <div className="w-12 h-12 bg-gradient-to-br from-red-400 to-red-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <Zap className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-xl font-bold text-gray-800 mb-2">Epic Battles</h3>
            <p className="text-gray-600">
              Pit your summoned Redditors against each other in battles of wit, karma, and meme supremacy!
            </p>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-shadow duration-300 text-center">
            <div className="w-12 h-12 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <Trophy className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-xl font-bold text-gray-800 mb-2">Hall of Fame</h3>
            <p className="text-gray-600">
              Track your greatest champions on the leaderboard and build your collection of legendary Redditors!
            </p>
          </div>
        </div>

        {/* Navigation Buttons */}
        <div className="flex flex-wrap justify-center gap-4">
          <button
            onClick={() => onNavigate('battle')}
            className="flex items-center gap-2 bg-white hover:bg-gray-50 text-gray-700 px-6 py-3 rounded-xl font-semibold shadow-md hover:shadow-lg transition-all duration-200"
          >
            <Zap className="w-5 h-5" />
            Battle Arena
          </button>
          
          <button
            onClick={() => onNavigate('leaderboard')}
            className="flex items-center gap-2 bg-white hover:bg-gray-50 text-gray-700 px-6 py-3 rounded-xl font-semibold shadow-md hover:shadow-lg transition-all duration-200"
          >
            <Trophy className="w-5 h-5" />
            Leaderboard
          </button>
        </div>

        {/* Fun Stats */}
        <div className="mt-16 text-center">
          <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-8 shadow-lg">
            <h3 className="text-2xl font-bold text-gray-800 mb-4">The Reddit Universe</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              <div>
                <div className="text-3xl font-bold text-orange-600">∞</div>
                <div className="text-sm text-gray-600">Possible Combos</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-red-600">100%</div>
                <div className="text-sm text-gray-600">Authentic Cringe</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-blue-600">24/7</div>
                <div className="text-sm text-gray-600">Meme Factory</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-purple-600">Epic</div>
                <div className="text-sm text-gray-600">Battles</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};