import React, { useState } from 'react';
import { RedditUser } from '../types';
import { RedditorCard } from './RedditorCard';
import { redditApi } from '../utils/redditApi';
import { saveToCollection } from '../utils/storage';
import { Sparkles, ArrowLeft, Zap, Save } from 'lucide-react';
import toast from 'react-hot-toast';

interface SummonScreenProps {
  onNavigate: (screen: string) => void;
}

export const SummonScreen: React.FC<SummonScreenProps> = ({ onNavigate }) => {
  const [currentRedditor, setCurrentRedditor] = useState<RedditUser | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSummon = async () => {
    setIsLoading(true);
    try {
      const redditor = await redditApi.generateRandomRedditor();
      setCurrentRedditor(redditor);
      toast.success(`Summoned u/${redditor.username}!`, {
        icon: '🎉',
        duration: 3000,
      });
    } catch (error) {
      toast.error('Summoning failed! The Reddit gods are displeased.', {
        icon: '😅',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveToCollection = () => {
    if (currentRedditor) {
      saveToCollection(currentRedditor);
      toast.success('Redditor saved to your collection!', {
        icon: '💾',
      });
    }
  };

  const handleBattle = () => {
    if (currentRedditor) {
      onNavigate('battle');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-50">
      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-800 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Home
          </button>
          
          <h1 className="text-3xl font-bold text-center text-gray-800">
            Summoning Chamber
          </h1>
          
          <div className="w-24"></div> {/* Spacer for centering */}
        </div>

        {/* Summon Button */}
        <div className="text-center mb-12">
          <button
            onClick={handleSummon}
            disabled={isLoading}
            className="group relative inline-flex items-center gap-3 bg-gradient-to-r from-purple-500 to-indigo-500 hover:from-purple-600 hover:to-indigo-600 disabled:from-gray-400 disabled:to-gray-500 text-white px-8 py-4 rounded-2xl font-bold text-xl shadow-xl hover:shadow-2xl transform hover:-translate-y-1 disabled:hover:translate-y-0 transition-all duration-300"
          >
            <Sparkles className={`w-6 h-6 ${isLoading ? 'animate-spin' : 'group-hover:animate-bounce'}`} />
            {isLoading ? 'Summoning...' : 'Summon Redditor'}
            <div className="absolute inset-0 bg-gradient-to-r from-purple-400 to-indigo-400 rounded-2xl blur opacity-30 group-hover:opacity-50 transition-opacity duration-300 -z-10"></div>
          </button>
        </div>

        {/* Loading Animation */}
        {isLoading && (
          <div className="text-center mb-8">
            <div className="inline-flex items-center gap-3 bg-white/80 backdrop-blur-sm rounded-xl px-6 py-3 shadow-lg">
              <div className="w-6 h-6 border-3 border-purple-500 border-t-transparent rounded-full animate-spin"></div>
              <span className="text-gray-700 font-medium">Accessing the Reddit hivemind...</span>
            </div>
          </div>
        )}

        {/* Redditor Card */}
        {currentRedditor && !isLoading && (
          <div className="flex justify-center mb-8">
            <RedditorCard 
              user={currentRedditor} 
              className="max-w-md w-full animate-fade-in"
            />
          </div>
        )}

        {/* Action Buttons */}
        {currentRedditor && !isLoading && (
          <div className="flex flex-wrap justify-center gap-4 mb-8">
            <button
              onClick={handleSaveToCollection}
              className="flex items-center gap-2 bg-green-500 hover:bg-green-600 text-white px-6 py-3 rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all duration-200"
            >
              <Save className="w-5 h-5" />
              Save to Collection
            </button>
            
            <button
              onClick={handleBattle}
              className="flex items-center gap-2 bg-red-500 hover:bg-red-600 text-white px-6 py-3 rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all duration-200"
            >
              <Zap className="w-5 h-5" />
              Battle Arena
            </button>

            <button
              onClick={handleSummon}
              className="flex items-center gap-2 bg-purple-500 hover:bg-purple-600 text-white px-6 py-3 rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all duration-200"
            >
              <Sparkles className="w-5 h-5" />
              Summon Another
            </button>
          </div>
        )}

        {/* Instructions */}
        {!currentRedditor && !isLoading && (
          <div className="max-w-2xl mx-auto text-center">
            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <h2 className="text-2xl font-bold text-gray-800 mb-4">Ready to Summon?</h2>
              <p className="text-gray-600 mb-6">
                Click the summon button to generate a completely random Reddit persona! 
                Each Redditor comes with authentic data pulled from the Reddit API, 
                including real usernames, subreddits, and comments (when available).
              </p>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="bg-orange-50 rounded-lg p-3">
                  <strong className="text-orange-800">Random Stats:</strong>
                  <br />Upvote power, cringe level, karma, and account age
                </div>
                <div className="bg-blue-50 rounded-lg p-3">
                  <strong className="text-blue-800">Real Data:</strong>
                  <br />Usernames and phrases from actual Reddit posts
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};