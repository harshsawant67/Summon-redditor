import React, { useState } from 'react';
import { RedditUser, BattleResult } from '../types';
import { RedditorCard } from './RedditorCard';
import { redditApi } from '../utils/redditApi';
import { saveToLeaderboard } from '../utils/storage';
import { ArrowLeft, Zap, Swords, Trophy, RotateCcw } from 'lucide-react';
import toast from 'react-hot-toast';

interface BattleScreenProps {
  onNavigate: (screen: string) => void;
}

export const BattleScreen: React.FC<BattleScreenProps> = ({ onNavigate }) => {
  const [fighter1, setFighter1] = useState<RedditUser | null>(null);
  const [fighter2, setFighter2] = useState<RedditUser | null>(null);
  const [battleResult, setBattleResult] = useState<BattleResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isBattling, setIsBattling] = useState(false);

  const generateFighters = async () => {
    setIsLoading(true);
    setBattleResult(null);
    
    try {
      const [redditor1, redditor2] = await Promise.all([
        redditApi.generateRandomRedditor(),
        redditApi.generateRandomRedditor()
      ]);
      
      setFighter1(redditor1);
      setFighter2(redditor2);
      
      toast.success('Battle fighters summoned!', {
        icon: '⚔️',
      });
    } catch (error) {
      toast.error('Failed to summon fighters!', {
        icon: '😅',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const startBattle = async () => {
    if (!fighter1 || !fighter2) return;
    
    setIsBattling(true);
    
    // Add dramatic delay for effect
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const result = redditApi.calculateBattleWinner(fighter1, fighter2);
    setBattleResult(result);
    
    // Save winner to leaderboard
    saveToLeaderboard(result.winner);
    
    toast.success(`${result.winner.username} wins!`, {
      icon: '🏆',
      duration: 4000,
    });
    
    setIsBattling(false);
  };

  const resetBattle = () => {
    setBattleResult(null);
    setFighter1(null);
    setFighter2(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 via-orange-50 to-yellow-50">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-800 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Home
          </button>
          
          <h1 className="text-3xl font-bold text-center text-gray-800 flex items-center gap-3">
            <Swords className="w-8 h-8 text-red-500" />
            Battle Arena
            <Swords className="w-8 h-8 text-red-500" />
          </h1>
          
          <div className="w-24"></div>
        </div>

        {/* Control Buttons */}
        <div className="text-center mb-8">
          <div className="flex flex-wrap justify-center gap-4">
            <button
              onClick={generateFighters}
              disabled={isLoading}
              className="flex items-center gap-2 bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 disabled:from-gray-400 disabled:to-gray-500 text-white px-6 py-3 rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all duration-200"
            >
              <Zap className={`w-5 h-5 ${isLoading ? 'animate-spin' : ''}`} />
              {isLoading ? 'Summoning...' : 'Generate Fighters'}
            </button>
            
            {fighter1 && fighter2 && !battleResult && (
              <button
                onClick={startBattle}
                disabled={isBattling}
                className="flex items-center gap-2 bg-gradient-to-r from-red-500 to-orange-500 hover:from-red-600 hover:to-orange-600 disabled:from-gray-400 disabled:to-gray-500 text-white px-6 py-3 rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all duration-200"
              >
                <Swords className={`w-5 h-5 ${isBattling ? 'animate-pulse' : ''}`} />
                {isBattling ? 'Battling...' : 'START BATTLE!'}
              </button>
            )}
            
            {battleResult && (
              <button
                onClick={resetBattle}
                className="flex items-center gap-2 bg-gradient-to-r from-green-500 to-teal-500 hover:from-green-600 hover:to-teal-600 text-white px-6 py-3 rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all duration-200"
              >
                <RotateCcw className="w-5 h-5" />
                New Battle
              </button>
            )}
          </div>
        </div>

        {/* Battle Animation */}
        {isBattling && (
          <div className="text-center mb-8">
            <div className="inline-flex items-center gap-3 bg-white/90 backdrop-blur-sm rounded-xl px-8 py-4 shadow-xl">
              <div className="w-8 h-8 border-4 border-red-500 border-t-transparent rounded-full animate-spin"></div>
              <span className="text-xl font-bold text-gray-800">Epic battle in progress...</span>
              <div className="w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
            </div>
          </div>
        )}

        {/* Battle Result */}
        {battleResult && (
          <div className="text-center mb-8">
            <div className="bg-gradient-to-r from-yellow-400 to-orange-400 rounded-2xl p-6 shadow-xl max-w-md mx-auto">
              <Trophy className="w-12 h-12 text-white mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-white mb-2">Victory!</h2>
              <p className="text-white text-lg">
                <strong>u/{battleResult.winner.username}</strong> {battleResult.reason}
              </p>
            </div>
          </div>
        )}

        {/* Fighters Display */}
        {fighter1 && fighter2 && (
          <div className="grid lg:grid-cols-2 gap-8 items-start">
            {/* Fighter 1 */}
            <div className="text-center">
              <div className={`mb-4 ${battleResult?.winner.id === fighter1.id ? 'animate-pulse' : battleResult?.loser.id === fighter1.id ? 'opacity-50' : ''}`}>
                <div className="bg-blue-500 text-white px-4 py-2 rounded-t-xl font-bold">
                  Fighter 1
                </div>
                <RedditorCard user={fighter1} />
              </div>
            </div>

            {/* VS Divider */}
            <div className="lg:hidden flex justify-center my-4">
              <div className="bg-gradient-to-r from-red-500 to-orange-500 text-white px-6 py-2 rounded-full font-bold text-lg shadow-lg">
                VS
              </div>
            </div>

            {/* Fighter 2 */}
            <div className="text-center">
              <div className={`mb-4 ${battleResult?.winner.id === fighter2.id ? 'animate-pulse' : battleResult?.loser.id === fighter2.id ? 'opacity-50' : ''}`}>
                <div className="bg-red-500 text-white px-4 py-2 rounded-t-xl font-bold">
                  Fighter 2
                </div>
                <RedditorCard user={fighter2} />
              </div>
            </div>
          </div>
        )}

        {/* Hidden VS indicator for desktop */}
        {fighter1 && fighter2 && (
          <div className="hidden lg:block absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2 z-10">
            <div className="bg-gradient-to-r from-red-500 to-orange-500 text-white px-8 py-4 rounded-full font-bold text-2xl shadow-xl">
              VS
            </div>
          </div>
        )}

        {/* Instructions */}
        {!fighter1 && !fighter2 && !isLoading && (
          <div className="max-w-2xl mx-auto text-center">
            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <h2 className="text-2xl font-bold text-gray-800 mb-4">Battle Arena Rules</h2>
              <p className="text-gray-600 mb-6">
                Two Redditors enter, one Redditor leaves! Generate two random fighters and watch them 
                duke it out based on their stats. The winner is determined by a complex algorithm 
                considering upvote power, karma, and cringe levels.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                <div className="bg-blue-50 rounded-lg p-3">
                  <strong className="text-blue-800">Upvote Power:</strong>
                  <br />Raw internet influence
                </div>
                <div className="bg-green-50 rounded-lg p-3">
                  <strong className="text-green-800">Karma:</strong>
                  <br />Accumulated reputation
                </div>
                <div className="bg-red-50 rounded-lg p-3">
                  <strong className="text-red-800">Cringe Level:</strong>
                  <br />Higher = worse chances
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};