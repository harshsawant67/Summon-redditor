import { RedditUser } from '../types';

const LEADERBOARD_KEY = 'summon_redditor_leaderboard';
const COLLECTION_KEY = 'summon_redditor_collection';

export const saveToLeaderboard = (user: RedditUser): void => {
  const existingData = localStorage.getItem(LEADERBOARD_KEY);
  const leaderboard: RedditUser[] = existingData ? JSON.parse(existingData) : [];
  
  // Check if user already exists
  const existingIndex = leaderboard.findIndex(u => u.username === user.username);
  
  if (existingIndex >= 0) {
    leaderboard[existingIndex] = { ...leaderboard[existingIndex], battleWins: (leaderboard[existingIndex].battleWins || 0) + 1 };
  } else {
    leaderboard.push({ ...user, battleWins: (user.battleWins || 0) + 1 });
  }
  
  // Sort by battle wins and keep top 10
  leaderboard.sort((a, b) => (b.battleWins || 0) - (a.battleWins || 0));
  const topLeaderboard = leaderboard.slice(0, 10);
  
  localStorage.setItem(LEADERBOARD_KEY, JSON.stringify(topLeaderboard));
};

export const getLeaderboard = (): RedditUser[] => {
  const data = localStorage.getItem(LEADERBOARD_KEY);
  return data ? JSON.parse(data) : [];
};

export const saveToCollection = (user: RedditUser): void => {
  const existingData = localStorage.getItem(COLLECTION_KEY);
  const collection: RedditUser[] = existingData ? JSON.parse(existingData) : [];
  
  // Avoid duplicates
  if (!collection.find(u => u.id === user.id)) {
    collection.push(user);
    localStorage.setItem(COLLECTION_KEY, JSON.stringify(collection));
  }
};

export const getCollection = (): RedditUser[] => {
  const data = localStorage.getItem(COLLECTION_KEY);
  return data ? JSON.parse(data) : [];
};