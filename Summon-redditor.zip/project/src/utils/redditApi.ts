import { RedditUser, RedditPost } from '../types';

const CORS_PROXY = 'https://api.allorigins.win/raw?url=';

// Fallback data in case Reddit API fails
const FALLBACK_USERNAMES = [
  'CatLover9000', 'MemeLord420', 'RedditNinja', 'UpvoteHunter', 'KarmaFarmer',
  'SirMemes', 'LolCatQueen', 'EpicGamer2023', 'PizzaAddict', 'CoffeeCodeDad',
  'AvocadoToast', 'WholesomeMemer', 'DankMemeDealer', 'NightOwl247', 'PunMaster',
  'SnugglePanda', 'TacoTuesday', 'ChaoticGoodBoi', 'SassyUnicorn', 'NerdAlert'
];

const POPULAR_SUBREDDITS = [
  'memes', 'funny', 'aww', 'todayilearned', 'pics', 'gaming', 'worldnews',
  'askreddit', 'explainlikeimfive', 'lifeprotips', 'showerthoughts', 'technology',
  'science', 'food', 'movies', 'music', 'books', 'art', 'programming', 'cats'
];

const CRINGE_PHRASES = [
  "This!", "Thanks for the gold kind stranger!", "I also choose this guy's wife",
  "Came here to say this", "Underrated comment", "Take my upvote", "Edit: RIP my inbox",
  "Username checks out", "Instructions unclear", "Perfectly balanced, as all things should be",
  "Reddit moment", "Wholesome 100", "Big chungus", "The narwhal bacons at midnight",
  "I'm not crying, you're crying", "Take my poor man's gold 🏅"
];

const EMOJIS = ['😎', '🤓', '😂', '🙄', '🔥', '💯', '👑', '🤡', '🧠', '💀', '🚀', '⭐'];

class RedditApiService {
  private async fetchRedditData(endpoint: string): Promise<any> {
    try {
      const response = await fetch(`${CORS_PROXY}https://www.reddit.com${endpoint}.json`);
      if (!response.ok) throw new Error('API call failed');
      return await response.json();
    } catch (error) {
      console.warn('Reddit API failed, using fallback data:', error);
      return null;
    }
  }

  private getRandomItem<T>(array: T[]): T {
    return array[Math.floor(Math.random() * array.length)];
  }

  private generateRandomStats() {
    return {
      upvotePower: Math.floor(Math.random() * 10000) + 100,
      cringeLevel: Math.floor(Math.random() * 100) + 1,
      karma: Math.floor(Math.random() * 1000000) + 1000,
      accountAge: `${Math.floor(Math.random() * 10) + 1} years`,
      favoriteEmoji: this.getRandomItem(EMOJIS)
    };
  }

  private generateAvatar(): string {
    // Using a diverse set of placeholder avatars
    const avatarServices = [
      `https://api.dicebear.com/7.x/avataaars/svg?seed=${Math.random()}`,
      `https://api.dicebear.com/7.x/fun-emoji/svg?seed=${Math.random()}`,
      `https://api.dicebear.com/7.x/bottts/svg?seed=${Math.random()}`,
    ];
    return this.getRandomItem(avatarServices);
  }

  async generateRandomRedditor(): Promise<RedditUser> {
    const stats = this.generateRandomStats();
    
    // Try to fetch real data, fallback to mock data
    const postsData = await this.fetchRedditData('/r/all/hot');
    const commentsData = await this.fetchRedditData('/r/all/comments');

    let username = this.getRandomItem(FALLBACK_USERNAMES);
    let subreddits = [...POPULAR_SUBREDDITS].sort(() => 0.5 - Math.random()).slice(0, 3);
    let phrases = [...CRINGE_PHRASES].sort(() => 0.5 - Math.random()).slice(0, 2);

    // Extract real data if available
    if (postsData?.data?.children) {
      const posts = postsData.data.children;
      const randomPost = this.getRandomItem(posts);
      if (randomPost?.data?.author && randomPost.data.author !== '[deleted]') {
        username = randomPost.data.author;
      }
      if (randomPost?.data?.subreddit) {
        subreddits = [randomPost.data.subreddit, ...subreddits.slice(0, 2)];
      }
    }

    if (commentsData?.data?.children) {
      const comments = commentsData.data.children;
      const validComments = comments
        .filter((c: any) => c.data?.body && c.data.body.length > 10 && c.data.body.length < 100)
        .map((c: any) => c.data.body);
      
      if (validComments.length > 0) {
        phrases = [this.getRandomItem(validComments), ...phrases.slice(0, 1)];
      }
    }

    return {
      id: `redditor_${Date.now()}_${Math.random()}`,
      username,
      avatar: this.generateAvatar(),
      subreddits,
      phrases,
      ...stats,
      battleWins: 0
    };
  }

  calculateBattleWinner(user1: RedditUser, user2: RedditUser): { winner: RedditUser; loser: RedditUser; reason: string } {
    const user1Score = user1.upvotePower + user1.karma / 1000 - user1.cringeLevel;
    const user2Score = user2.upvotePower + user2.karma / 1000 - user2.cringeLevel;
    
    const reasons = [
      "won with superior meme knowledge!",
      "dominated with epic karma farming skills!",
      "crushed the competition with dank memes!",
      "achieved victory through pure Reddit wisdom!",
      "conquered with the power of upvotes!",
      "triumphed with legendary shitposting abilities!",
      "won by being less cringe... somehow!",
      "achieved glory through superior Reddit addiction!"
    ];

    if (user1Score > user2Score) {
      return { winner: user1, loser: user2, reason: this.getRandomItem(reasons) };
    } else {
      return { winner: user2, loser: user1, reason: this.getRandomItem(reasons) };
    }
  }
}

export const redditApi = new RedditApiService();