import React, { useState } from 'react';
import { Toaster } from 'react-hot-toast';
import { GameScreen } from './types';
import { HomePage } from './components/HomePage';
import { SummonScreen } from './components/SummonScreen';
import { BattleScreen } from './components/BattleScreen';
import { Leaderboard } from './components/Leaderboard';
import { Footer } from './components/Footer';

function App() {
  const [currentScreen, setCurrentScreen] = useState<GameScreen>('home');

  const navigateToScreen = (screen: GameScreen) => {
    setCurrentScreen(screen);
  };

  const renderCurrentScreen = () => {
    switch (currentScreen) {
      case 'home':
        return <HomePage onNavigate={navigateToScreen} />;
      case 'summon':
        return <SummonScreen onNavigate={navigateToScreen} />;
      case 'battle':
        return <BattleScreen onNavigate={navigateToScreen} />;
      case 'leaderboard':
        return <Leaderboard onNavigate={navigateToScreen} />;
      default:
        return <HomePage onNavigate={navigateToScreen} />;
    }
  };

  return (
    <div className="min-h-screen">
      {renderCurrentScreen()}
      <Footer />
      <Toaster
        position="top-center"
        toastOptions={{
          duration: 3000,
          style: {
            background: '#fff',
            color: '#333',
            borderRadius: '12px',
            padding: '16px',
            fontSize: '14px',
            fontWeight: '500',
            boxShadow: '0 10px 25px rgba(0, 0, 0, 0.1)',
          },
        }}
      />
    </div>
  );
}

export default App;