export interface RedditUser {
  id: string;
  username: string;
  avatar: string;
  subreddits: string[];
  phrases: string[];
  upvotePower: number;
  cringeLevel: number;
  karma: number;
  accountAge: string;
  favoriteEmoji: string;
  battleWins?: number;
}

export interface BattleResult {
  winner: RedditUser;
  loser: RedditUser;
  reason: string;
}

export interface RedditPost {
  title: string;
  subreddit: string;
  author: string;
  score: number;
  comments: string[];
}

export type GameScreen = 'home' | 'summon' | 'battle' | 'leaderboard';